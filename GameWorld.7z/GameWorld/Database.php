<?php
$host = "localhost";
$user = "root";
$pass = "Admin";
$database = "gameworld";
$con = mysqli_connect($host,$user,$pass,$database);
/*/
if(mysqli_connect_errno())
{
    echo "falied to connect to MYSQL: " . mysqli_connect_errno();
}
else{
    echo "abbedabie abbedaboe";
}
/*/
?>