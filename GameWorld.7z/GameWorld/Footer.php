<footer>
<div id="credit"> © sjors vogels 2018 </div> 
</footer>