<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="description" content="Game world">
	<link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
    <?php 
include 'navigation.php';
?>
    <div id ="Info">
        <h1> About us </h1>
  
        <p> HI <br> 
    my name is sjors vogels. <br>
    together with my team we selesct the greatest games for you to play. <br>
    we sell games for your enjoyment  and we have free shipping <br></p>
  <p>  we hope you heve a good time and ejoy your games<br>
    have fun</p> 
    -sjors vogels
    </div>   
    </body>
    <?php
    include 'Footer.php';
    ?>