
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="description" content="Game world">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php 
include 'navigation.php';
?>
<body>
<div id = "contact">
<form method='POST'>
<ul>
<li><label> E-mail</label><input type="text" name="E-mail" required></li>
<li><label>Subject</label><input type="text" name="subject" required></li>
<div id= "Message">
<li><label> Message</label><input type="text" name="Message" required></li>
</div>
<li><input type="submit" name="Sent" class = Sent></li>
<?php#
$_POST;
//Email information
$admin_email = "sjor.c9@hotmail.com";
$email = $_POST['E-mail'];
$subject = $_POST['subject'];
$comment = $_POST['Message'];

//send email
mail($admin_email, "$subject", $comment, "From:" . $email);

?>
</ul>
</form>
</div>
</html>
<?php
    include 'Footer.php';
    ?>