
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="description" content="Game world">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php 
include 'navigation.php';
?>
 
    <div id= "homepage">
    <div id ="welcome">  <H1> welcome to gameworld</H1></div> 
    <div id ="image">
    <img src=" images\hp.jpg ">   
    </div>  
            
</div>
</div>
</div> 

    <div id="pcButton">
     <a href ="productpage.php?gameCat=1" > pc</a> 
    </div>

    <div id="ps4Button">
     <a href ="productpage.php?gameCat=2"> ps4</a> 
	</div>    
    <div id="XboxButton">
     <a href ="productpage.php?gameCat=3"> XBoxOne</a> 
	</div>           
</body>
</html>
<?php
    include 'Footer.php';
    ?>