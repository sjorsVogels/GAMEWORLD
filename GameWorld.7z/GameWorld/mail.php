<?php#
$_GET;
//Email information
$admin_email = "gameworldcompanymanagement@gmail.com";
$email = $_POST['E-mail'];
$subject = $_POST['subject'];
$comment = $_POST['Message'];

//send email
mail($admin_email, "$subject", $comment, "From:" . $email);

?>