<header id="header">
<div id ="logo"><a href = "index.php"> gameworld </a>
</div>
<div id ="nav">
<ul>
	<li><a href ="index.php"> Home</a> </li>
    <li><a href ="aboutus.php"> about us </a>
    <li><a href ="productpage.php?gameCat=0"> games</a> </li>
    <li><a href ="contact.php"> contact</a></li>  
    <li><a href = "shoppingcart.php"> cart </a></li>  
</ul>
</div>
</header>