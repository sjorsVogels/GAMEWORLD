<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="description" content="Game world">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<?php
$Number = 1;
$gameCat = $_GET['gameCat'];

include 'Database.php';
include 'navigation.php';

switch($gameCat)
{
case '0':
$query = "catogoryID ='1' OR catogoryID = '2' OR catogoryID ='3'";
$console = "All Games";
 break;

case '1':
$query = "catogoryID ='1'";
$console = "PC games";
include 'PChead.php';
break;

case '2':
$query = " catogoryID = '2'";
$console = "PS4 Games";
include 'PS4head.php';
break;

case '3':
$query = " catogoryID ='3'";
$console = "XBOX ONE";
include 'XBOXhead.php';
break;

default:
 header('location:./productpage.php?gameCat=0');
exit;
break;
}

$sql = "SELECT * FROM games NATURAL JOIN category WHERE " . $query . " ORDER BY catogoryID";

$games = mysqli_query($con, $sql);

mysqli_close($con);


?>
<body>
<div id= "maincontainer">
	<?php
	foreach ($games as $game) {
	if ($Number == 4){
		// div needs to be floated to the right //?>		
		<div class="product-item last-product-item">
		<div class="product-image"><img src="<?php echo $game ["gameImg"];?>"></div>
		<div class="product-name"><?php echo  $game["gameTitle"];?></div>
		<div class="product-price"> <?php echo $game ["gamePrice"];?></div>
		<div class="product-cart"><a href = "shoppingcart.php">Add to cart </a></div>
		</div>
		<?php
		$Number = 1;
	}
	else{
		?>
			<div class="product-item">
			<div class="product-image"><img src="<?php echo $game ["gameImg"];?>"></div>	
			<div class="product-name"><?php echo  $game["gameTitle"];?></div>
			<div class="product-price"> <?php echo $game ["gamePrice"];?></div>
			<div class="product-cart"><a href = "shoppingcart.php">Add to cart </a></div>
			</div>						
			<?php
			$Number = $Number + 1;		
		}
	}?>
	<div class="clearfix"></div>
</div>
</div>
</body>
</html>
<?php
    include 'Footer.php';
	?>
	