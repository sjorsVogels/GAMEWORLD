<?php 
include 'navigation.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="description" content="Game world">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id="checkaut">
<table style="width:100%">
  <tr>
    <th>image</th>
    <th>Game</th> 
    <th>Platform</th>
    <th>price</th>   
    
  </tr>
  <tr class = "tableColor1">
    <td> <img src="images\justcause4.jpg" alt="just cause 4"></td>
    <td>Just cause 4</td> 
    <td>pc</td>
    <td>59,99</td>
  </tr>
  <tr class = "tableColor2">
    <td><img src="images\overwatch.png" alt="OVERWATCH"></td>
    <td>Overwatch</td> 
    <td>PS4</td>
    <td>39,99</td>
  </tr>
  <tr class = "tableColor1">
    <td><img src="images\BFV.jpg" alt="Battle Field five"></td>
    <td>Battle field five</td> 
    <td>XBOX ONE</td>
    <td>79,99</td>
  </tr>
  <tr class = "TableColor2" >
  <td></td>
  <td></td>
  <td></td>
  <td>total:&euro;179,97</td>
  </tr> 
</table>
